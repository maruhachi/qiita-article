package com.example.infiniteloooooop

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class InfiniteLoooooopApplication

fun main(args: Array<String>) {
	runApplication<InfiniteLoooooopApplication>(*args)
}
