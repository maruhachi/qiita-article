rootProject.name = "infinite-loooooop"
